#!/usr/bin/perl -w
use DBI;
use DateTime;


### Functions used in this scripts.
sub getFQDN($);
sub pingCheck($);
sub trimString($);
sub execCmd(@);

### program specific functions
sub preConnectDB();
sub getRequestDetails();
sub processServerList(@);
sub updateDBTables($);

## Variable declarations goes here
$WINDIR =  $ENV{windir};
$systemBINDir = $WINDIR ."\\system32";

### Getting Date from DateTime Module
my $dt = DateTime->now;
$dt->set_time_zone( 'America/Chicago' );

$year   = sprintf ("%04d", $dt->year);
$month  = sprintf ("%02d", $dt->month); 
$day  = sprintf ("%02d", $dt->day);  
$hms    = $dt->hms;

$created = "${year}-${month}-${day} ${hms}";



my $reqID = "XXXX";
my @serverList = ();

$processID = $$;
$requestID = "REQ" . $year .$month . $day . $processID ;
my $outputFile = "C\:/temp/${requestID}_Ouput.csv";
my $tmpFile = "C\:/temp/${requestID}_tmp.log";
%alreadyExecuted = ();
%requestIDs = ();

### calling preconnect DB function here
preConnectDB();

## opening output file for writing
open(OUTPUT,">$outputFile") or die "cannot open $outputFile\n";
print OUTPUT "RequestId,Hostname,FQDN,IPAddress,Host Ping Status\n";


$numArgs = $#ARGV + 1;

if ($numArgs > 0) {  ### calling script with less than 5 hosts
	$reqID = $ARGV[0];
	foreach $argnum (1 .. $#ARGV) {  
		$searchHostLine = $ARGV[$argnum];
		@tmpServerList = split(/\,/, $searchHostLine);
		foreach $server (@tmpServerList) {
			$server = trimString($server);
			push(@serverList, "${reqID}\^${server}");
		}
		
	} ## end of argnum
	$requestIDs{$reqID} = 1;

} else {  ### calling script for batch processing

	print "Calling Batch Script \n";
	getRequestDetails();  ### Batch processing data gets here
}

processServerList(@serverList);
updateDBTables($outputFile);

### Cleanup Work4aig
#unlink($outputFile) if (-f $outputFile);
unlink($tmpFile) if (-f $tmpFile);

exit 0;


################################################################################
# ##############################################################################
# Open DB connection and clean all files
# ##############################################################################
################################################################################
sub processServerList(@) {
	my @workList = @_;
	
	foreach $workRequest (@workList) {
		(my $reqID, my $server) = split (/\^/, ${workRequest});
		next if (defined($alreadyExecuted{$server})); ### this statement is to avoid duplicate host runs
		$PingStatus = pingCheck($server);
		($FQDN,$IP) = getFQDN($server);
		$alreadyExecuted{$server} = 1;
		print OUTPUT "$reqID,$server,Completed,$FQDN,$IP,$PingStatus,$created\n";
	
	}

	close(OUTPUT);
}

################################################################################
# ##############################################################################
# Get Request details for batch processing
# ##############################################################################
################################################################################
sub getRequestDetails() {
	$selectCommand = "Select DPS.REQ_ID,DPS.Entered_Host from Candor.DNSLookup_Ping_Stats DPS where DPS.Work_Status = \'Not Started\' ";	
	
	$sth = $dbh->prepare($selectCommand) || die "DNS prepare: $selectCommand: $DBI::errstr"; 
	$sth->execute || die "DNS execute: $selectCommand: $DBI::errstr"; 
	
	# Fetch and display the result set value.
	while ( my @columns = $sth->fetchrow_array() ) {
		chomp(@columns);
		$reqID = $columns[0];
		#$reqID = chmod($reqID);
		
		$searchHostLine = trimString($columns[1]);
		@tmpServerList = split(/\,/, $searchHostLine);
		foreach $server (@tmpServerList) {
			$server = trimString($server);
			push(@serverList, "${reqID}\^${server}");
			$requestIDs{$reqID} = 1;
		}
		next;
	}
	
	return;
}

################################################################################
# ##############################################################################
# Open DB connection and clean all files
# ##############################################################################
################################################################################
sub preConnectDB() {

########## Connecting to Database Server Here
	$database = "candor";
	$host = "10.97.65.203";
	$port = "3307";
	$user = "root";
	$password = "Work4aig";

	#DATA SOURCE NAME
	$dbh = DBI->connect("DBI:mysql:database=$database;host=$host;port=$port",
					  $user, $password, {RaiseError => 1});

	return;
}

################################################################################
# ##############################################################################
# Update DB tables with respective data
# ##############################################################################
################################################################################
sub updateDBTables($) {
	$IPFile = shift;

# ########## Connecting to Database Server Here
	# $database = "candor";
	# $host = "PWGSDPDWH01";
	# $port = "3307";
	# $user = "root";
	# $password = "Work4aig";

	# #DATA SOURCE NAME
	# $dbh = DBI->connect("DBI:mysql:database=$database;host=$host;port=$port",
					  # $user, $password, {RaiseError => 1});
					  
	#print "\n####################################################################################\n\nNow, Started Working on updating Database Tables \n";
	
	## Delete command execution
	#step 1# Delete exisitng request IDs in the table 
	 for my $reqID ( keys %requestIDs ) {
		$deleteCommand = "DELETE from Candor.DNSLookup_Ping_Stats where REQ_ID = \'$reqID\'";
		$sth = $dbh->prepare($deleteCommand) || die "DNS delete prepare: $deleteCommand: $DBI::errstr"; 
		$sth->execute || die "DNS delete execute: $deleteCommand: $DBI::errstr"; 
    }

	#step 2# Updating CMDB Server data
	$loadCommand = "LOAD DATA LOCAL INFILE \'$IPFile\' INTO TABLE Candor.DNSLookup_Ping_Stats \
					FIELDS TERMINATED BY \'\,\' \
					ENCLOSED BY \'\"\'  \
					LINES TERMINATED BY \'\\r\\n\' \
					IGNORE 1 LINES
					(REQ_ID,Entered_Host,Work_Status,FQDN_Name,IP_Address,Ping_Status,created)";
					
	
	$sth = $dbh->prepare($loadCommand) || die "DNS Update prepare: $loadCommand: $DBI::errstr"; 
	$sth->execute || die "DNS Update execute: $loadCommand: $DBI::errstr"; 
	$dbh->disconnect();
	return;
}


###############################################################################
# trimString function to trim unnecessary spaces and characters in a string 
###############################################################################

sub trimString($)
{
    $string = shift;
    return "" if (!defined($string));
    $string =~ s/\[Null\]//g;
    $string =~ s/\s+//g;
    $string =~ s/\"//g;
    $string =~ s/\,//g;
    $string = lc $string;
    return $string
}

###############################################################################
# executing nslookup command, and check FQDN.  
###############################################################################
sub getFQDN($)
{
	my ($server) = shift;
	my $nslookupFQDN = "Cannot be Determined";
	my $ipAddress = "xx.xx.xx.xx";
	
	$nslookupCommand = "$systemBINDir\\nslookup.exe ${server} > $tmpFile";
	#printLog("Executing nslookup command : $nslookupCommand");
	execCmd($nslookupCommand, "Trouble executing nslookup command on $server : ");

	## reading the nslookup output
	open(TMP,"<$tmpFile") or die "cannot open $tmpFile\n";

	
	while(<TMP>){
		my $FQDNLine = $_;
		($junk, $nslookupFQDN) = split(/\:/, $FQDNLine) if ($FQDNLine =~ /Name/i) ;		## Name is read into junk parameter
		chomp($nslookupFQDN);
		$nslookupFQDN = trimString($nslookupFQDN) if ($FQDNLine =~ /Name/i) ;	## trim all un necessary spaces in output string
		
		($junk, $ipAddress) = split(/\:/, $FQDNLine) if ($FQDNLine =~ /Address/i) ;		## Name is read into junk parameter
		$ipAddress = trimString($ipAddress) if ($FQDNLine =~ /Address/i) ;	## trim all un necessary spaces in output string
		
	}
	close(TMP);
	unlink($tmpFile);
	
	### updating ping status as nslookup picking up gateway address.
	$ipAddress = "xx.xx.xx.xx" if ($nslookupFQDN eq "Cannot be Determined");
	#print "Finished checking ping on $server and the status : $pStatus \n";	
return ($nslookupFQDN,$ipAddress) ;
}	
	
###############################################################################
# executing ping command, and check status code.  Bail if nonzero
###############################################################################
sub pingCheck($)
{
	my ($server) = shift;
	my $pStatus = "Failed";
	
	$pingCommand = "$systemBINDir\\ping.exe -n 1 ${server} > $tmpFile";
	#printLog("Executing ping commane : $pingCommand");
	execCmd($pingCommand, "Trouble executing ping command on $server : ");

	## reading the ping output
	open(TMP,"<$tmpFile") or die "cannot open $tmpFile\n";

	while(<TMP>){
		my $line = $_;
		$pStatus = "Good :Pingable" if ($line =~ /Reply from/i);
		$pStatus = "System-Down" if ($line =~ /Request timed out/i);
		$pStatus = "Cannot find Host" if ($line =~ /could not find host/i);	
		$pStatus = "Host Cannot Reach" if ($line =~ /Destination host unreachable/i);
		$pStatus = "TTL Expired in Transit" if ($line =~ /TTL Expired in Transit/i);
		$pStatus = "Failed" if ($line =~ /100\% loss/i);
	}
	close(TMP);
	unlink($tmpFile);
	#print "Finished checking ping on $server and the status : $pStatus \n";	
return $pStatus;
}	

################################################################################
# Executing command line command
################################################################################
sub execCmd(@)
{
    my ($Cmd, $errMsg) = @_;
	#print "Executing : " . $Cmd ."\n";
	system($Cmd);
	# if ( $? >> 8 ) {
	# if ( $? > 10 ) {
		# print "$errMsg $! \n";
		# print "Erros in executing $Cmd \n Please check the logs after completion of the program \n command return code : $? \n";
	# }
}
	
